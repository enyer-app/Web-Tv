package com.tvlivepro.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
