/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { HomeScreen } from './components/HomeScreen';
import { PreRollAd } from './components/PreRollAd';
import { LivePlayer } from './components/LivePlayer';
import { AdminPanel } from './components/AdminPanel';
import { AuthScreen, getActiveSession, logoutSession } from './components/AuthScreen';
import { ConfigProvider, useAppConfig } from './context/ConfigContext';
import { AlertTriangle, Settings } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { AdScriptLoader } from './components/AdScriptLoader';
import { auth } from './lib/firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';

type AppState = 'home' | 'ad' | 'playing' | 'maintenance' | 'admin';

// Custom lightweight router hook to detect '/admin' or '#admin'
function useCurrentRoute() {
  const [route, setRoute] = useState(() => {
    const path = window.location.pathname.toLowerCase();
    const hash = window.location.hash.toLowerCase();
    if (path.endsWith('/admin') || path === '/admin' || hash === '#admin') {
      return 'admin';
    }
    return 'app';
  });

  useEffect(() => {
    const handleUrlChange = () => {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      if (path.endsWith('/admin') || path === '/admin' || hash === '#admin') {
        setRoute('admin');
      } else {
        setRoute('app');
      }
    };

    window.addEventListener('hashchange', handleUrlChange);
    window.addEventListener('popstate', handleUrlChange);
    
    return () => {
      window.removeEventListener('hashchange', handleUrlChange);
      window.removeEventListener('popstate', handleUrlChange);
    };
  }, []);

  return route;
}

function AppContent() {
  const { config } = useAppConfig();
  const currentRoute = useCurrentRoute();

  const [userEmail, setUserEmail] = useState<string | null>(() => getActiveSession());
  const [appState, setAppState] = useState<AppState>('admin');

  // Synchronize Firebase Auth changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setUserEmail(user.email);
        localStorage.setItem('tv_live_pro_active_session', user.email || '');
      } else {
        // Safe check for local fallback session
        const localSession = getActiveSession();
        if (!localSession) {
          setUserEmail(null);
        }
      }
    });
    return () => unsubscribe();
  }, []);

  // Force administrator dashboard view
  useEffect(() => {
    setAppState('admin');
  }, [currentRoute]);

  const startStream = () => {
    if (config.enableAd) {
      setAppState('ad');
    } else {
      setAppState('playing');
    }
  };

  const onAdComplete = () => {
    setAppState('playing');
  };

  const goBack = () => {
    setAppState('home');
  };

  const handleExitAdmin = () => {
    // Navigate away from admin path or hash
    if (window.location.hash === '#admin') {
      window.location.hash = '';
    } else if (window.location.pathname.endsWith('/admin')) {
      window.history.pushState({}, '', window.location.origin);
    }
    // Instantly notify current route listeners
    window.dispatchEvent(new Event('popstate'));
    setAppState('home');
  };

  const handleAuthSuccess = (email: string) => {
    setUserEmail(email);
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.error("Firebase logout error trace:", e);
    }
    logoutSession();
    setUserEmail(null);
  };

  return (
    <main className="w-full h-screen bg-black text-white relative overflow-hidden font-sans">
      <AnimatePresence mode="wait">
        {appState === 'admin' && (
          <motion.div
            key="admin"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="w-full h-full relative z-50 overflow-y-auto"
          >
            {userEmail ? (
              <AdminPanel onBack={handleExitAdmin} userEmail={userEmail} onLogout={handleLogout} />
            ) : (
              <AuthScreen onSuccess={handleAuthSuccess} appName={config.appName} onBack={handleExitAdmin} />
            )}
          </motion.div>
        )}

        {appState === 'home' && (
          <motion.div
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="w-full h-full"
          >
            <HomeScreen onStart={startStream} />
          </motion.div>
        )}

        {appState === 'ad' && (
          <motion.div
            key="ad"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="w-full h-full"
          >
            <PreRollAd onComplete={onAdComplete} />
          </motion.div>
        )}

        {appState === 'playing' && (
          <motion.div
            key="player"
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="w-full h-full"
          >
            <LivePlayer streamUrl={config.streamUrl} onBack={goBack} />
          </motion.div>
        )}

        {appState === 'maintenance' && (
          <motion.div
            key="maintenance"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-[#050505] flex flex-col items-center justify-center p-4 text-center z-[200] overflow-hidden select-none"
          >
            {/* Authentic SMPTE Style Retro TV Color Bars Background */}
            <div className="absolute inset-0 flex flex-col pointer-events-none opacity-40 z-0 scale-105">
              <div className="flex-1 w-full flex">
                <div className="flex-1 bg-[#ffffff]" />
                <div className="flex-1 bg-[#dede00]" />
                <div className="flex-1 bg-[#00dede]" />
                <div className="flex-1 bg-[#00de00]" />
                <div className="flex-1 bg-[#de00de]" />
                <div className="flex-1 bg-[#de0000]" />
                <div className="flex-1 bg-[#0000de]" />
              </div>
              <div className="h-12 w-full flex">
                <div className="flex-1 bg-[#0000de]" />
                <div className="flex-1 bg-[#151515]" />
                <div className="flex-1 bg-[#de00de]" />
                <div className="flex-1 bg-[#151515]" />
                <div className="flex-1 bg-[#00dede]" />
                <div className="flex-1 bg-[#151515]" />
                <div className="flex-1 bg-[#ffffff]" />
              </div>
              <div className="h-20 w-full flex">
                <div className="w-[15%] bg-[#00214c]" />
                <div className="w-[15%] bg-[#ffffff]" />
                <div className="w-[15%] bg-[#32006a]" />
                <div className="w-[15%] bg-[#151515]" />
                <div className="w-[10%] bg-[#090909]" />
                <div className="w-[10%] bg-[#151515]" />
                <div className="w-[10%] bg-[#212121]" />
                <div className="flex-1 bg-[#151515]" />
              </div>
            </div>

            {/* Simulated TV Scanlines / Noise Overlay */}
            <div 
              className="absolute inset-0 pointer-events-none opacity-[0.16] z-10"
              style={{
                backgroundImage: `repeating-linear-gradient(0deg, #000 0px, #000 2px, transparent 2px, transparent 4px)`
              }}
            />

            {/* Sweep animated horizontal bar */}
            <div className="absolute w-full h-[3px] bg-white/20 top-0 left-0 animate-sweep z-10" />

            {/* Centered High Fidelity glassmorphism screen plate */}
            <div className="relative bg-black/80 backdrop-blur-2xl border border-white/10 p-8 md:p-12 rounded-2xl max-w-xl w-full mx-4 shadow-[0_0_80px_rgba(0,0,0,0.8)] z-20 flex flex-col items-center">
              
              {/* Animated Live Warning Light */}
              <div className="flex items-center gap-3 px-4 py-2 bg-neutral-900/80 rounded-full border border-white/5 mb-8">
                <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse" />
                <span className="text-[10px] uppercase tracking-[0.2em] font-black text-neutral-300">Señal Fuera de Al aire</span>
              </div>

              <div className="relative mb-6">
                <AlertTriangle className="w-16 h-16 text-[#ff0000] drop-shadow-[0_0_15px_rgba(255,0,0,0.4)] animate-bounce" />
              </div>

              <h1 className="text-3xl md:text-4xl font-black mb-3 uppercase tracking-tighter italic text-white font-sans">
                Mantenimiento Técnico
              </h1>
              <p className="text-neutral-400 text-sm md:text-base leading-relaxed mb-8 max-w-sm font-light">
                Estamos optimizando los servidores de <span className="text-white font-bold">{config.appName}</span> para brindarte mayor estabilidad y definición. Disculpa las molestias.
              </p>

              {/* Technical indicators inside plate */}
              <div className="w-full bg-black/60 border border-white/5 rounded-lg p-4 grid grid-cols-2 gap-4 text-left font-mono mb-8">
                <div>
                  <span className="text-[9px] uppercase tracking-wider text-neutral-500 block">SISTEMA ELECTRÓNICO</span>
                  <span className="text-xs text-neutral-200 font-bold">ONLINE (PRE-READY)</span>
                </div>
                <div>
                  <span className="text-[9px] uppercase tracking-wider text-neutral-500 block">SEÑAL DE VÍDEO</span>
                  <span className="text-xs text-red-500 font-bold">CALIBRANDO</span>
                </div>
                <div className="col-span-2 pt-2 border-t border-white/5">
                  <span className="text-[9px] uppercase tracking-wider text-neutral-500 block">TIEMPO ESTIMADO</span>
                  <span className="text-xs text-yellow-500 font-bold">CONEXIÓN REANUDABLE EN BREVE</span>
                </div>
              </div>
            </div>

            {/* Footer Tag */}
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-white/30 text-xs font-bold tracking-[0.25em] uppercase z-20">
              {config.appName} &copy; TV BROADCAST SERVICE
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Real ad scripts dynamic injector */}
      {appState !== 'admin' && (
        <AdScriptLoader htmlCode={config.adScriptCode} />
      )}

      {/* Removed persistent overlay border that overrides the player and other screens */}
    </main>
  );
}

export default function App() {
  return (
    <ConfigProvider>
      <AppContent />
    </ConfigProvider>
  );
}
