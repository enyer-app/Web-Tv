import { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, doc, setDoc, deleteDoc, onSnapshot } from 'firebase/firestore';

// Common bots and crawler identifiers in User-Agent header
const BOT_USER_AGENTS = [
  'bot', 'crawl', 'slurp', 'spider', 'archiver', 'curl', 'wget', 'lighthouse',
  'python', 'headless', 'selenium', 'puppeteer', 'phantomjs', 'googlebot',
  'bingbot', 'yandex', 'baidu', 'facebookexternalhit', 'twitterbot', 'linkedinbot'
];

/**
 * Custom Hook to track real human viewer counts in real-time.
 * Filters out automated bots, automated scripts, crawlers, and headless scrapers.
 * Stores heartbeats in Firestore to calculate 100% real active sessions.
 */
export function useRealViewers() {
  const [isHuman, setIsHuman] = useState(false);
  const [viewersCount, setViewersCount] = useState(0);

  // Generate or retrieve a persistent viewer session ID for this browser tab
  const getSessionViewerId = (): string => {
    if (typeof window === 'undefined') return 'server';
    let id = sessionStorage.getItem('tv_live_pro_viewer_id');
    if (!id) {
      id = 'v_' + Math.random().toString(36).substring(2, 12) + '_' + Date.now();
      sessionStorage.setItem('tv_live_pro_viewer_id', id);
    }
    return id;
  };

  // Determine if browser is a crawler/bot
  const detectBot = (): boolean => {
    if (typeof window === 'undefined') return true;
    
    // 1. Check navigator.webdriver (true for Selenium, Puppeteer, etc.)
    if (navigator.webdriver) return true;

    // 2. Check for common headless browser flags
    const userAgent = navigator.userAgent.toLowerCase();
    const isBotUA = BOT_USER_AGENTS.some(bot => userAgent.includes(bot));
    if (isBotUA) return true;

    // 3. Screen size matching headless defaults (e.g. 800x600 with 0 depth)
    if (window.screen && (window.screen.width === 0 || window.screen.height === 0)) return true;

    return false;
  };

  // 1. Listen for real human inputs to flag as a verified viewer
  useEffect(() => {
    const isBot = detectBot();
    if (isBot) {
      return;
    }

    const handleHumanInteraction = () => {
      setIsHuman(true);
      cleanupListeners();
    };

    const cleanupListeners = () => {
      window.removeEventListener('mousemove', handleHumanInteraction);
      window.removeEventListener('keydown', handleHumanInteraction);
      window.removeEventListener('touchstart', handleHumanInteraction);
      window.removeEventListener('scroll', handleHumanInteraction);
      window.removeEventListener('click', handleHumanInteraction);
    };

    // Listen for real human inputs
    window.addEventListener('mousemove', handleHumanInteraction);
    window.addEventListener('keydown', handleHumanInteraction);
    window.addEventListener('touchstart', handleHumanInteraction);
    window.addEventListener('scroll', handleHumanInteraction);
    window.addEventListener('click', handleHumanInteraction);

    // If already detected as active from previous interaction, we can auto-verify
    if (sessionStorage.getItem('tv_live_pro_human_verified') === 'true') {
      setIsHuman(true);
      cleanupListeners();
    }

    return cleanupListeners;
  }, []);

  // 2. Store human-verified status to session storage to persist across soft pages
  useEffect(() => {
    if (isHuman) {
      sessionStorage.setItem('tv_live_pro_human_verified', 'true');
    }
  }, [isHuman]);

  // 3. Heartbeat & Presence engine with Firestore database
  useEffect(() => {
    if (!isHuman) return;

    const viewerId = getSessionViewerId();
    const docRef = doc(db, 'viewers', viewerId);

    // Dynamic heartbeat to declare active presence
    const sendHeartbeat = async () => {
      try {
        await setDoc(docRef, {
          lastActive: Date.now(),
          userAgent: navigator.userAgent
        });
      } catch (e) {
        console.warn("Could not write viewer presence to Firestore directly: ", e);
      }
    };

    // Initial heartbeat
    sendHeartbeat();

    // Loop heartbeat every 10 seconds to maintain presence
    const interval = setInterval(sendHeartbeat, 10000);

    // Clean up presence on unmount / crash
    const handleUnload = () => {
      try {
        deleteDoc(docRef);
      } catch (e) {
        // Safe sink
      }
    };

    window.addEventListener('beforeunload', handleUnload);

    return () => {
      clearInterval(interval);
      window.removeEventListener('beforeunload', handleUnload);
      handleUnload();
    };
  }, [isHuman]);

  // 4. Real-time Subscription to calculate all active human connections globally
  useEffect(() => {
    const colRef = collection(db, 'viewers');

    const unsubscribe = onSnapshot(colRef, (snapshot) => {
      const now = Date.now();
      const cutoffTime = now - 25000; // 25 seconds activity window
      
      let count = 0;
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        if (data && typeof data.lastActive === 'number' && data.lastActive >= cutoffTime) {
          count++;
        }
      });

      setViewersCount(count);
    }, (error) => {
      console.warn("Firestore count read access denied or pending. Using offline counts.", error);
      setViewersCount(0);
    });

    return () => unsubscribe();
  }, []);

  return {
    isHuman,
    viewersCount,
    userAgent: typeof window !== 'undefined' ? navigator.userAgent : ''
  };
}
