import { useEffect } from 'react';

type Direction = 'up' | 'down' | 'left' | 'right' | 'enter' | 'back';

export function useRemoteControl(onAction: (action: Direction) => void) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowUp':
          onAction('up');
          break;
        case 'ArrowDown':
          onAction('down');
          break;
        case 'ArrowLeft':
          onAction('left');
          break;
        case 'ArrowRight':
          onAction('right');
          break;
        case 'Enter':
          onAction('enter');
          break;
        case 'Escape':
        case 'Backspace':
          onAction('back');
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onAction]);
}
