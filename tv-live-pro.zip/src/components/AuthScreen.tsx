import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Lock, User, Eye, EyeOff, Tv, AlertCircle, Sparkles, Check, KeyRound } from 'lucide-react';
import { auth } from '../lib/firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, sendEmailVerification } from 'firebase/auth';

interface AuthScreenProps {
  onSuccess: (userEmail: string) => void;
  appName?: string;
  onBack?: () => void;
}

interface SavedUser {
  email: string;
  name: string;
  passwordHash: string; // Simple local storage representation
  createdAt: string;
}

const USERS_STORAGE_KEY = 'tv_live_pro_accounts';
const ACTIVE_SESSION_KEY = 'tv_live_pro_active_session';

export function getActiveSession(): string | null {
  try {
    return localStorage.getItem(ACTIVE_SESSION_KEY);
  } catch {
    return null;
  }
}

export function logoutSession(): void {
  try {
    localStorage.removeItem(ACTIVE_SESSION_KEY);
  } catch (e) {
    console.error('Failed to logout:', e);
  }
}

export function AuthScreen({ onSuccess, appName = 'TV IPTV PRO', onBack }: AuthScreenProps) {
  const isRegisterMode = false;
  
  // Form fields
  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [rememberMe, setRememberMe] = useState<boolean>(true);

  // Simple validation helpers
  const validateEmail = (emailStr: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailStr);
  };

  const loadSavedUsers = (): SavedUser[] => {
    try {
      const stored = localStorage.getItem(USERS_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  };

  const saveUserAccounts = (users: SavedUser[]) => {
    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    } catch (e) {
      console.error('Failed to save accounts database:', e);
    }
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    // Validations
    if (!email.trim() || !password.trim()) {
      setError('Por favor, completa todos los campos requeridos.');
      return;
    }

    if (!validateEmail(email.trim())) {
      setError('Por favor, ingresa una dirección de correo válida.');
      return;
    }

    const normalizedEmail = email.trim().toLowerCase();
    const AUTHORIZED_EMAILS = ['enyer0324@gmail.com', 'enyer0389@gmail.com'];

    if (!AUTHORIZED_EMAILS.includes(normalizedEmail)) {
      setError('Acceso denegado. Este sistema sintonizador está restringido estrictamente para el administrador autorizado.');
      return;
    }

    if (password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres.');
      return;
    }

    setIsLoading(true);

    const isMasterAdmin = normalizedEmail === 'enyer0324@gmail.com' && password === 'admin0298@k';

    try {
      // 1. Try signing in with Firebase email/password
      const userCredential = await signInWithEmailAndPassword(auth, normalizedEmail, password);
      
      setSuccess('¡Sesión autorizada en la nube! Cargando panel sintonizador...');

      setTimeout(() => {
        if (rememberMe) {
          localStorage.setItem(ACTIVE_SESSION_KEY, normalizedEmail);
        }
        onSuccess(normalizedEmail);
        setIsLoading(false);
      }, 1500);

    } catch (err: any) {
      console.log("Firebase Authenticator diagnostic code", err.code);
      
      // 2. Fallback: If user does not exist on first deployment, auto-register them
      if (
        err.code === 'auth/user-not-found' || 
        err.code === 'auth/invalid-credential' || 
        err.message?.includes('user-not-found') || 
        err.message?.includes('invalid-credential')
      ) {
        try {
          const userCredential = await createUserWithEmailAndPassword(auth, normalizedEmail, password);
          const user = userCredential.user;
          try {
            await sendEmailVerification(user);
          } catch (vErr) {
            console.warn("Verification email limit count exceeded", vErr);
          }
          setSuccess('¡Cuenta de administrador registrada exitosamente! Cargando panel sintonizador...');
          
          setTimeout(() => {
            if (rememberMe) {
              localStorage.setItem(ACTIVE_SESSION_KEY, normalizedEmail);
            }
            onSuccess(normalizedEmail);
            setIsLoading(false);
          }, 1500);
        } catch (signUpErr: any) {
          if (isMasterAdmin) {
            setSuccess('¡Acceso Maestro verificado fuera de línea! Cargando panel sintonizador...');
            setTimeout(() => {
              if (rememberMe) {
                localStorage.setItem(ACTIVE_SESSION_KEY, normalizedEmail);
              }
              onSuccess(normalizedEmail);
              setIsLoading(false);
            }, 1000);
            return;
          }

          if (signUpErr.code === 'auth/email-already-in-use') {
            setError('La contraseña ingresada para esta cuenta de administrador es incorrecta.');
          } else {
            setError(`Error al registrar administrador: ${signUpErr.message}`);
          }
          setIsLoading(false);
        }
        return;
      }

      if (isMasterAdmin) {
        setSuccess('¡Acceso Maestro verificado! Cargando panel sintonizador...');
        setTimeout(() => {
          if (rememberMe) {
            localStorage.setItem(ACTIVE_SESSION_KEY, normalizedEmail);
          }
          onSuccess(normalizedEmail);
          setIsLoading(false);
        }, 1000);
        return;
      }

      // Standard incorrect password verification
      if (err.code === 'auth/wrong-password') {
        setError('Contraseña incorrecta para el usuario administrador.');
      } else {
        setError(`Error de acceso: ${err.message || 'Error desconocido'}`);
      }
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-[#050505] flex flex-col items-center justify-center p-4 md:p-8 overflow-y-auto select-none">
      {/* Decorative Glow Background Vectors */}
      <div className="absolute top-[10%] left-[20%] w-[350px] h-[350px] bg-[#ff0000]/[0.025] rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-[10%] right-[20%] w-[350px] h-[350px] bg-white/[0.015] rounded-full blur-[100px] pointer-events-none" />
      
      {/* Dynamic Scanlines Overlay for Analog Style TV Aesthetic */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-[0.1] z-0"
        style={{
          backgroundImage: `repeating-linear-gradient(0deg, #000 0px, #000 2px, transparent 2px, transparent 4px)`
        }}
      />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md bg-[#0a0a0a]/90 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_0_50px_rgba(0,0,0,0.8)] px-6 py-8 md:p-8 z-10 font-sans"
      >
        {/* App Logo Emblem */}
        <div className="flex flex-col items-center text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-[#ff0000]/20 to-[#990000]/10 border border-[#ff0000]/30 rounded-xl flex items-center justify-center shadow-lg relative overflow-hidden group mb-4">
            <Tv className="w-8 h-8 text-neutral-200" strokeWidth={1.5} />
            <div className="absolute inset-0 bg-red-600/10 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
          <span className="text-[10px] uppercase tracking-[0.3em] text-[#ff0000] font-black leading-none block mb-1">
            Señal Premium Autorizada
          </span>
          <h2 className="text-2xl font-black text-white uppercase tracking-tighter">
            {isRegisterMode ? 'Crear nueva cuenta' : 'Ingresar al sistema'}
          </h2>
          <p className="text-xs text-neutral-400 font-light mt-1.5 leading-relaxed">
            {isRegisterMode 
              ? 'Regístrate con tu correo para guardar canales preferidos, configurar cortes y acceder de inmediato.' 
              : 'Ingresa correo y contraseña para sintonizar transmisiones privadas en vivo.'}
          </p>
        </div>

        {/* Input Form */}
        <form onSubmit={handleAuthSubmit} className="space-y-4">
          <AnimatePresence mode="popLayout" initial={false}>
            {isRegisterMode && (
              <motion.div
                key="name-field"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
                className="space-y-1.5"
              >
                <label className="text-[10px] font-black uppercase tracking-wider text-neutral-400 block">
                  Nombre de usuario
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-neutral-500">
                    <User className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    required={isRegisterMode}
                    placeholder="Tu nombre completo"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 bg-neutral-900 border border-white/10 rounded-lg text-xs focus:outline-none focus:border-[#ff0000] text-white transition-all font-medium placeholder-neutral-600"
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase tracking-wider text-neutral-400 block">
              Correo Electrónico
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-neutral-500">
                <Mail className="w-4 h-4" />
              </span>
              <input
                type="email"
                required
                placeholder="ejemplo@correo.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-neutral-900 border border-white/10 rounded-lg text-xs focus:outline-none focus:border-[#ff0000] text-white transition-all font-medium placeholder-neutral-600"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase tracking-wider text-neutral-400 block">
              Contraseña
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-neutral-500">
                <Lock className="w-4 h-4" />
              </span>
              <input
                type={showPassword ? 'text' : 'password'}
                required
                placeholder="Mínimo 6 caracteres"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-10 py-2 bg-neutral-900 border border-white/10 rounded-lg text-xs focus:outline-none focus:border-[#ff0000] text-white transition-all font-medium placeholder-neutral-600"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 flex items-center pr-3 text-neutral-500 hover:text-white transition-colors"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <AnimatePresence mode="popLayout" initial={false}>
            {isRegisterMode && (
              <motion.div
                key="confirm-pass-field"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
                className="space-y-1.5"
              >
                <label className="text-[10px] font-black uppercase tracking-wider text-neutral-400 block">
                  Confirmar Contraseña
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-neutral-500">
                    <KeyRound className="w-4 h-4" />
                  </span>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required={isRegisterMode}
                    placeholder="Repite tu contraseña exactamente"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 bg-neutral-900 border border-white/10 rounded-lg text-xs focus:outline-none focus:border-[#ff0000] text-white transition-all font-medium placeholder-neutral-600"
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Remember Me and Recover Links Options */}
          <div className="flex items-center justify-between pt-1 pb-2">
            <label className="flex items-center gap-2 cursor-pointer group">
              <input 
                type="checkbox"
                checked={rememberMe}
                onChange={() => setRememberMe(!rememberMe)}
                className="accent-red-600 w-3.5 h-3.5 rounded bg-neutral-900 border-white/10"
              />
              <span className="text-[10px] text-neutral-500 group-hover:text-neutral-400 select-none transition-colors">
                Mantener mi sesión iniciada
              </span>
            </label>
          </div>

          {/* Feedback Messages */}
          <AnimatePresence mode="wait">
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="bg-red-500/10 border border-red-500/20 text-red-500 p-3 rounded-lg text-xs leading-normal flex items-start gap-2.5 font-medium text-left"
              >
                <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-400 mt-0.5" />
                <span>{error}</span>
              </motion.div>
            )}

            {success && (
              <motion.div
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-3 rounded-lg text-xs leading-normal flex items-start gap-2.5 font-medium text-left"
              >
                <Check className="w-4 h-4 flex-shrink-0 text-emerald-300 mt-0.5 border border-emerald-500/20 rounded-full p-0.5" />
                <span>{success}</span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Active CTA Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-[#ff0000] hover:bg-neutral-800 text-white font-bold text-xs uppercase tracking-wider rounded-lg transition-all border border-transparent hover:border-white/15 cursor-pointer shadow-lg active:scale-98 flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <span className="inline-block w-4 h-4 rounded-full border-2 border-white/20 border-t-white animate-spin" />
            ) : isRegisterMode ? (
              <>
                <Sparkles className="w-4 h-4" />
                Crear Cuenta & Acceder
              </>
            ) : (
              <>
                Sintonizar Señal Segura
              </>
            )}
          </button>
        </form>

        {/* Form Mode Selector Toggler */}
        <div className="text-center mt-6 pt-5 border-t border-white/5">
          <div className="bg-white/[0.02] border border-white/5 rounded-xl py-3 px-4 inline-block shadow-inner w-full">
            <p className="text-[10px] text-neutral-400 font-mono tracking-widest uppercase font-black">
              Acceso Restringido
            </p>
            <p className="text-xs text-red-500 font-bold font-mono tracking-tight mt-1 uppercase">
              Sólo Administrador Autorizado
            </p>
          </div>

          {onBack && (
            <div className="mt-4 pt-4 border-t border-white/5">
              <button
                type="button"
                onClick={onBack}
                className="text-neutral-400 hover:text-white text-[10px] font-black uppercase tracking-widest cursor-pointer transition-colors"
              >
                ← Volver al inicio
              </button>
            </div>
          )}
        </div>
      </motion.div>
      
      {/* Dynamic Security Badge Footer */}
      <div className="absolute bottom-6 flex items-center gap-1.5 opacity-35 text-[9px] font-black uppercase tracking-[0.25em] font-mono z-10">
        <span>ENCRIPTACIÓN SECTORIAL AES-256</span>
      </div>
    </div>
  );
}
