import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { useAppConfig } from '../context/ConfigContext';

interface PreRollAdProps {
  onComplete: () => void;
}

export function PreRollAd({ onComplete }: PreRollAdProps) {
  const { config } = useAppConfig();
  const [timeLeft, setTimeLeft] = useState(config.adDurationSeconds);

  useEffect(() => {
    if (timeLeft === 0) {
      onComplete();
      return;
    }
    const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, onComplete]);

  return (
    <div className="fixed inset-0 bg-[#050505] flex flex-col items-center justify-center z-[100] p-4 md:p-8 lg:p-16">
      <div className="relative w-full max-w-5xl aspect-video bg-neutral-900 overflow-hidden rounded-xl shadow-[0_0_50px_rgba(255,255,255,0.1)] border border-white/10">
        <video 
          autoPlay 
          muted 
          className="w-full h-full object-cover"
          src={config.adVideoUrl}
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute top-4 left-4 md:top-12 md:left-12">
          <span className="bg-[#ff0000] text-white px-2 py-1 md:px-4 md:py-2 text-[10px] md:text-xs font-black uppercase tracking-widest rounded-sm shadow-lg">
            Publicidad
          </span>
        </div>
        <div className="absolute bottom-4 right-4 md:bottom-12 md:right-12">
          <div className="bg-white/5 backdrop-blur-2xl px-4 py-2 md:px-8 md:py-4 rounded-lg border border-white/20 shadow-2xl">
            <p className="text-white text-sm md:text-lg font-bold tracking-tight">
              Señal en {timeLeft}s
            </p>
          </div>
        </div>
      </div>
      <div className="mt-6 md:mt-12 flex items-center gap-2 md:gap-4 opacity-40">
        <div className="w-1.5 h-1.5 md:w-2 md:h-2 rounded-full bg-white animate-pulse" />
        <p className="text-white text-[10px] md:text-sm font-medium uppercase tracking-[0.2em] md:tracking-[0.4em]">
          Estabilizando Señal Premium
        </p>
      </div>
    </div>
  );
}

