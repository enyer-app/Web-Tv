import React, { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';
import { 
  Play, Pause, Volume2, VolumeX, Maximize, Minimize, RefreshCw, Cast, 
  ArrowLeft, Loader2, AlertCircle, ExternalLink, FastForward, Rewind, 
  Monitor, LayoutList, Megaphone, X, Sparkles, ChevronRight, ChevronLeft,
  Copy, Check, Music, Upload, Trash2, Disc, Sliders
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useRemoteControl } from '../hooks/useRemoteControl';
import { useAppConfig } from '../context/ConfigContext';

interface LivePlayerProps {
  streamUrl: string;
  onBack: () => void;
}

export function LivePlayer({ streamUrl, onBack }: LivePlayerProps) {
  const { config, updateConfig, setActiveStream } = useAppConfig();
  
  // Ref elements
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // States
  const [resolvedUrl, setResolvedUrl] = useState<string | null>(null);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showControls, setShowControls] = useState(true);

  // HTML5 Playback States
  const [isPlaying, setIsPlaying] = useState(true);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPipSupported, setIsPipSupported] = useState(false);

  // Layout Drawers
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isMusicDrawerOpen, setIsMusicDrawerOpen] = useState(false);
  const [showCastError, setShowCastError] = useState(false);
  const isInIframe = window.self !== window.top;

  // Background Music HUD States
  const audioRef = useRef<HTMLAudioElement>(null);
  const [resolvedMusicUrl, setResolvedMusicUrl] = useState<string | null>(null);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const [localSongs, setLocalSongs] = useState<{ id: string; title: string; sizeCount: string; createdAt: number }[]>([]);
  const [isUploadingMusic, setIsUploadingMusic] = useState(false);
  const [musicProgress, setMusicProgress] = useState(0);
  const [selectedMusicId, setSelectedMusicId] = useState<string>('');
  const [playerToast, setPlayerToast] = useState<string | null>(null);

  // Integrated Sponsors & Ads states
  const [showBannerAd, setShowBannerAd] = useState(true);
  const [interactiveAdState, setInteractiveAdState] = useState<'idle' | 'buffering' | 'running' | 'completed'>('idle');
  const [adTimer, setAdTimer] = useState(8);

  const currentVideoIndex = config.videoLibrary?.findIndex(v => v.url === streamUrl) ?? -1;
  const currentVideoTitle = currentVideoIndex !== -1 ? config.videoLibrary[currentVideoIndex].title : 'Canal Activo';

  // Check PIP support on mount
  useEffect(() => {
    if (document.pictureInPictureEnabled) {
      setIsPipSupported(true);
    }
  }, []);

  // Playlist handlers
  const playNextVideo = () => {
    if (!config.videoLibrary || config.videoLibrary.length === 0) return;
    let nextIndex = 0;
    if (currentVideoIndex !== -1) {
      nextIndex = (currentVideoIndex + 1) % config.videoLibrary.length;
    }
    const nextVideo = config.videoLibrary[nextIndex];
    if (nextVideo) {
      setError(null);
      setIsLoading(true);
      setActiveStream(nextVideo.url, nextVideo.title.replace(/^📁 \[Local\] /, ''));
    }
  };

  const playPrevVideo = () => {
    if (!config.videoLibrary || config.videoLibrary.length === 0) return;
    let prevIndex = config.videoLibrary.length - 1;
    if (currentVideoIndex !== -1) {
      prevIndex = (currentVideoIndex - 1 + config.videoLibrary.length) % config.videoLibrary.length;
    }
    const prevVideo = config.videoLibrary[prevIndex];
    if (prevVideo) {
      setError(null);
      setIsLoading(true);
      setActiveStream(prevVideo.url, prevVideo.title.replace(/^📁 \[Local\] /, ''));
    }
  };

  const showPlayerToast = (msg: string) => {
    setPlayerToast(msg);
    setTimeout(() => setPlayerToast(null), 3000);
  };

  const loadLocalSongs = async () => {
    try {
      const { getAllAudioFiles } = await import('../lib/videoDb');
      const files = await getAllAudioFiles();
      setLocalSongs(files);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadLocalSongs();
  }, [isMusicDrawerOpen]);

  // Sync native repetition attribute with looping configuration
  useEffect(() => {
    const video = videoRef.current;
    if (video) {
      video.loop = !!config.loopVideo;
    }
  }, [config.loopVideo, resolvedUrl]);

  // Resolve selected music track binary raw blob to object URL
  useEffect(() => {
    let activeMusicUrl: string | null = null;
    let isMounted = true;

    const resolveMusic = async () => {
      if (!selectedMusicId) {
        setResolvedMusicUrl(null);
        setIsMusicPlaying(false);
        return;
      }

      if (selectedMusicId.startsWith('local-music-')) {
        try {
          const { getVideoBlob } = await import('../lib/videoDb');
          const blob = await getVideoBlob(selectedMusicId);
          if (blob && isMounted) {
            const objUrl = URL.createObjectURL(blob);
            activeMusicUrl = objUrl;
            setResolvedMusicUrl(objUrl);
          }
        } catch (err) {
          console.error("Error loading local audio blob:", err);
        }
      }
    };

    resolveMusic();

    return () => {
      isMounted = false;
      if (activeMusicUrl) {
        URL.revokeObjectURL(activeMusicUrl);
      }
    };
  }, [selectedMusicId]);

  // Synchronize playing states between video player and customized back music
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying && resolvedMusicUrl && interactiveAdState === 'idle') {
      audio.play()
        .then(() => setIsMusicPlaying(true))
        .catch(err => console.log("Audio play blocked by browser sandbox policy:", err));
    } else {
      audio.pause();
      setIsMusicPlaying(false);
    }
  }, [isPlaying, resolvedMusicUrl, interactiveAdState]);

  // Sync background music volume
  useEffect(() => {
    const audio = audioRef.current;
    if (audio) {
      audio.volume = config.backgroundMusicVolume !== undefined ? config.backgroundMusicVolume : 0.5;
    }
  }, [config.backgroundMusicVolume, resolvedMusicUrl]);

  // Custom audio track file uploader
  const handleMusicUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/')) {
      showPlayerToast('Por favor, selecciona un archivo de audio (.mp3, .wav, .m4a, etc.)');
      return;
    }

    setIsUploadingMusic(true);
    setMusicProgress(15);

    try {
      const interval = setInterval(() => {
        setMusicProgress(p => p >= 85 ? 85 : p + 15);
      }, 70);

      const { saveAudioFile } = await import('../lib/videoDb');
      const saved = await saveAudioFile(file.name, file);

      clearInterval(interval);
      setMusicProgress(100);

      setTimeout(() => {
        setIsUploadingMusic(false);
        setMusicProgress(0);
        showPlayerToast('🎵 ¡Música subida con éxito!');
        loadLocalSongs();
        setSelectedMusicId(saved.id);
      }, 400);
    } catch (err) {
      console.error(err);
      setIsUploadingMusic(false);
      setMusicProgress(0);
      showPlayerToast('Error al guardar la pista musical');
    }
  };

  const handleMusicDelete = async (id: string, name: string) => {
    try {
      const { deleteVideoFile } = await import('../lib/videoDb');
      await deleteVideoFile(id);
      if (selectedMusicId === id) {
        setSelectedMusicId('');
      }
      showPlayerToast(`Eliminado: ${name}`);
      loadLocalSongs();
    } catch (e) {
      console.error(e);
    }
  };

  // Autoplay and ended listeners
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleVideoEnded = () => {
      if (config.loopVideo) {
        console.log("Transmission item finished, looping single video infinitely...");
        video.currentTime = 0;
        video.play().catch(() => {});
      } else {
        console.log("Transmission item finished, advancing playlist...");
        playNextVideo();
      }
    };

    video.addEventListener('ended', handleVideoEnded);
    return () => {
      video.removeEventListener('ended', handleVideoEnded);
    };
  }, [streamUrl, config.videoLibrary, currentVideoIndex, config.loopVideo]);

  // Handle play and pause (only play is allowed to prevent pause)
  const handlePlayPause = () => {
    if (interactiveAdState !== 'idle') return;
    const video = videoRef.current;
    if (!video) return;

    if (video.paused) {
      video.play().then(() => setIsPlaying(true)).catch(() => {});
    }
    resetControlsTimeout();
  };

  // Adjust seek time (disabled to prevent fast forward/retroceder)
  const handleSeek = (amount: number) => {
    // Seeking disabled on live TV transmission
  };

  // Sync volume slider
  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    const video = videoRef.current;
    if (video) {
      video.volume = newVolume;
      video.muted = newVolume === 0;
      setIsMuted(newVolume === 0);
    }
    resetControlsTimeout();
  };

  // Toggle Mute
  const handleToggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    const nextMute = !video.muted;
    video.muted = nextMute;
    setIsMuted(nextMute);
    if (!nextMute && volume === 0) {
      setVolume(0.5);
      video.volume = 0.5;
    }
    resetControlsTimeout();
  };

  // HTML5 video events observer
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);
    const onTimeUpdate = () => setCurrentTime(video.currentTime);
    const onDurationChange = () => setDuration(video.duration || 0);

    video.addEventListener('play', onPlay);
    video.addEventListener('pause', onPause);
    video.addEventListener('timeupdate', onTimeUpdate);
    video.addEventListener('durationchange', onDurationChange);

    return () => {
      video.removeEventListener('play', onPlay);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('timeupdate', onTimeUpdate);
      video.removeEventListener('durationchange', onDurationChange);
    };
  }, [resolvedUrl]);

  // Picture in picture handler
  const handleTogglePip = async () => {
    try {
      const video = videoRef.current;
      if (!video) return;

      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else {
        await video.requestPictureInPicture();
      }
    } catch (err) {
      console.error("PiP request failed:", err);
    }
  };

  // Reload current source
  const handleReload = () => {
    setError(null);
    setIsLoading(true);
    setResolvedUrl(null);
    setTimeout(() => {
      setResolvedUrl(streamUrl);
    }, 150);
  };

  // Toggle FullScreen
  const toggleFullScreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await containerRef.current?.requestFullscreen();
        setIsFullScreen(true);
        if (screen.orientation && (screen.orientation as any).lock) {
          try {
            await (screen.orientation as any).lock('landscape');
          } catch (e) {
            console.log("No landscape orientation lock:", e);
          }
        }
      } else {
        await document.exitFullscreen();
        setIsFullScreen(false);
        if (screen.orientation && screen.orientation.unlock) {
          screen.orientation.unlock();
        }
      }
    } catch (err) {
      console.error("FullScreen error:", err);
    }
  };

  // Casting trigger helper
  const handleCast = async () => {
    const video = videoRef.current as any;
    if (isInIframe) {
      setShowCastError(true);
      setTimeout(() => setShowCastError(false), 9000);
      return;
    }

    const hasRemotePlayback = video && video.remote && video.remote.prompt;
    const hasWebKitPicker = video && video.webkitShowPlaybackTargetPicker;

    try {
      if (hasRemotePlayback) {
        await video.remote.prompt();
      } else if (hasWebKitPicker) {
        video.webkitShowPlaybackTargetPicker();
      } else {
        setShowCastError(true);
      }
    } catch (err: any) {
      if (err.name !== 'NotAllowedError' && err.name !== 'AbortError') {
        setShowCastError(true);
        setTimeout(() => setShowCastError(false), 8000);
      }
    }
  };

  // Automatically hide controls after interaction
  const resetControlsTimeout = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false);
      }
    }, 4500);
  };

  // Physical keyboard support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (interactiveAdState !== 'idle') {
        if (e.key.toLowerCase() === 'escape') {
          if (isFullScreen) {
            document.exitFullscreen().catch(() => {});
            setIsFullScreen(false);
          }
        }
        return;
      }
      resetControlsTimeout();
      const video = videoRef.current;
      if (!video) return;

      switch (e.key.toLowerCase()) {
        case ' ':
          e.preventDefault();
          // Spacebar pause disabled by user command
          break;
        case 'f':
          e.preventDefault();
          toggleFullScreen();
          break;
        case 'm':
          e.preventDefault();
          handleToggleMute();
          break;
        case 'arrowleft':
          e.preventDefault();
          // Seek disabled
          break;
        case 'arrowright':
          e.preventDefault();
          // Seek disabled
          break;
        case 'arrowup':
          e.preventDefault();
          const incVolume = Math.min(1, video.volume + 0.05);
          setVolume(incVolume);
          video.volume = incVolume;
          video.muted = false;
          setIsMuted(false);
          break;
        case 'arrowdown':
          e.preventDefault();
          const decVolume = Math.max(0, video.volume - 0.05);
          setVolume(decVolume);
          video.volume = decVolume;
          if (decVolume === 0) {
            setIsMuted(true);
            video.muted = true;
          }
          break;
        case 'escape':
          if (isFullScreen) {
            document.exitFullscreen().catch(() => {});
            setIsFullScreen(false);
          }
          break;
        default:
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isFullScreen, volume, isMuted, interactiveAdState]);

  // Remote controller integration
  useRemoteControl((action) => {
    if (interactiveAdState !== 'idle') return;
    resetControlsTimeout();
    if (action === 'enter') {
      handlePlayPause();
    } else if (action === 'back') {
      if (document.fullscreenElement) {
        document.exitFullscreen();
        setIsFullScreen(false);
      } else {
        onBack();
      }
    }
  });

  // Resolve media URL (dynamic import logic)
  useEffect(() => {
    let activeUrl: string | null = null;
    let isMounted = true;

    const resolveStreamUrl = async () => {
      if (!streamUrl) {
        if (isMounted) {
          setError("No hay ningún canal o video activo configurado actualmente. Ve a la Consola de Administración para agregar enlaces.");
          setIsLoading(false);
        }
        return;
      }
      if (streamUrl.startsWith('local-')) {
        try {
          const { getVideoBlob } = await import('../lib/videoDb');
          const blob = await getVideoBlob(streamUrl);
          if (blob && isMounted) {
            const objUrl = URL.createObjectURL(blob);
            activeUrl = objUrl;
            setResolvedUrl(objUrl);
          } else if (isMounted) {
            setError("No se pudo cargar el archivo local. Asegúrate de haberlo subido correctamente en el panel.");
            setIsLoading(false);
          }
        } catch (err) {
          console.error("Error loading local video from IndexedDB:", err);
          if (isMounted) {
            setError("Error al leer el archivo de video local del dispositivo.");
            setIsLoading(false);
          }
        }
      } else {
        if (isMounted) {
          setResolvedUrl(streamUrl);
        }
      }
    };

    resolveStreamUrl();

    return () => {
      isMounted = false;
      if (activeUrl) {
        URL.revokeObjectURL(activeUrl);
      }
    };
  }, [streamUrl]);

  // Initialize HLS.js or HTML5 Player sources
  useEffect(() => {
    if (!resolvedUrl) return;
    const video = videoRef.current;
    if (!video) return;

    let hls: Hls;
    const isHlsUrl = streamUrl.toLowerCase().includes('.m3u8');

    if (isHlsUrl && Hls.isSupported()) {
      hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
        backBufferLength: 90,
      });
      hls.loadSource(resolvedUrl);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        video.play()
          .then(() => {
            setIsPlaying(true);
            setIsLoading(false);
          })
          .catch((err) => {
            console.warn("HLS Autoplay blocked. Retrying muted...", err);
            video.muted = true;
            setIsMuted(true);
            video.play()
              .then(() => {
                setIsPlaying(true);
                setIsLoading(false);
              })
              .catch((err2) => {
                console.warn("HLS Muted autoplay also blocked. User interaction required:", err2);
                setIsPlaying(false);
                setIsLoading(false);
              });
          });
      });
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls.recoverMediaError();
              break;
            default:
              setError("Error crítico en el stream HLS.");
              hls.destroy();
              break;
          }
        }
      });
    } else {
      video.src = resolvedUrl;
      
      const handleCanPlay = () => {
        video.play()
          .then(() => {
            setIsPlaying(true);
            setIsLoading(false);
          })
          .catch((err) => {
            console.warn("Native player autoplay blocked. Retrying muted...", err);
            video.muted = true;
            setIsMuted(true);
            video.play()
              .then(() => {
                setIsPlaying(true);
                setIsLoading(false);
              })
              .catch((err2) => {
                console.warn("Native Muted autoplay also blocked. User interaction required:", err2);
                setIsPlaying(false);
                setIsLoading(false);
              });
          });
      };

      const handleVideoError = () => {
        setError("Error de transmisión. Por favor, verifica la URL o el archivo del canal.");
        setIsLoading(false);
      };

      video.addEventListener('canplay', handleCanPlay);
      video.addEventListener('error', handleVideoError);

      return () => {
        video.removeEventListener('canplay', handleCanPlay);
        video.removeEventListener('error', handleVideoError);
      };
    }

    return () => {
      if (hls) hls.destroy();
    };
  }, [resolvedUrl, streamUrl]);

  // Observe Fullscreen toggling state
  useEffect(() => {
    const handleFsChange = () => {
      setIsFullScreen(!!document.fullscreenElement);
      if (!document.fullscreenElement) setShowControls(true);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  // Trigger ad simulation event
  const triggerSimulatedAd = () => {
    resetControlsTimeout();
    setInteractiveAdState('buffering');
    setTimeout(() => {
      setInteractiveAdState('running');
      setAdTimer(8);
    }, 1200);
  };

  // Robust countdown timer for integration ads
  useEffect(() => {
    let intervalId: any = null;
    if (interactiveAdState === 'running') {
      intervalId = setInterval(() => {
        setAdTimer((prev) => {
          if (prev <= 1) {
            clearInterval(intervalId);
            setInteractiveAdState('completed');
            setTimeout(() => {
              setInteractiveAdState('idle');
            }, 2000);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [interactiveAdState]);

  // Pause the main video stream during ads, and resume play immediately after ad completion
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    if (interactiveAdState === 'buffering' || interactiveAdState === 'running' || interactiveAdState === 'completed') {
      if (!video.paused) {
        video.pause();
        setIsPlaying(false);
      }
    } else if (interactiveAdState === 'idle') {
      // Stream is restored, trigger automatic video playback
      video.play()
        .then(() => {
          setIsPlaying(true);
        })
        .catch((err) => {
          console.warn("Autoplay recovery after ad failed:", err);
        });
    }
  }, [interactiveAdState]);

  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || seconds === Infinity) return '--:--';
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);

    if (hrs > 0) {
      return `${hrs}:${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
    }
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div 
      ref={containerRef}
      className={`fixed inset-0 bg-black flex transition-all duration-500 overflow-hidden ${
        showControls ? 'cursor-default' : 'cursor-none'
      }`}
      onMouseMove={resetControlsTimeout}
      onTouchStart={resetControlsTimeout}
    >
      {/* MAIN THEATER CONTAINER */}
      <div className="flex-1 h-full relative flex flex-col items-center justify-center bg-zinc-950">
        
        {/* Decorative glass scanline glow texture for authentic TV look */}
        <div className="absolute inset-0 pointer-events-none opacity-[0.03] z-[5] bg-[linear-gradient(rgba(18,16,16,0)_50%,_rgba(0,0,0,0.25)_50%),_linear-gradient(90deg,_rgba(255,0,0,0.06),_rgba(0,255,0,0.02),_rgba(0,0,255,0.06))] bg-[size:100%_4px,_6px_100%]" />

        {/* Clicking anywhere on viewport shows/resets controls and plays if paused */}
        <div 
          onClick={() => {
            if (!isPlaying) {
              handlePlayPause();
            } else {
              resetControlsTimeout();
            }
          }}
          className="w-full h-full relative flex items-center justify-center group/video cursor-pointer"
        >
          <video
            ref={videoRef}
            className="w-full h-full object-contain transition-all"
            playsInline
            autoPlay
            x-webkit-airplay="allow"
          />
          <audio
            ref={audioRef}
            src={resolvedMusicUrl || undefined}
            loop
            className="hidden"
          />
        </div>

        {/* SPONSOR BANNER ADS */}
        {showBannerAd && !error && !isLoading && (
          <div className="absolute bottom-28 md:bottom-36 left-4 md:left-8 z-[15] max-w-[280px] sm:max-w-md">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              className="bg-black/95 backdrop-blur-xl border border-white/10 p-3.5 rounded-lg shadow-2xl relative"
            >
              <button 
                onClick={() => setShowBannerAd(false)}
                className="absolute top-1 right-1 p-1 hover:bg-white/10 rounded text-neutral-400 hover:text-white transition-colors"
                title="Cerrar patrocinio"
              >
                <X className="w-3 h-3" />
              </button>
              
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-gradient-to-br from-amber-500/20 to-red-500/20 rounded-md border border-amber-500/20 text-amber-400 flex-shrink-0">
                  <Megaphone className="w-4 h-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <span className="text-[8px] font-black uppercase text-amber-500 tracking-[0.2em] block">Señal Patrocinada</span>
                  <p className="text-[11px] font-bold text-white truncate leading-tight">Acceso Premium Activo sin Interrupción</p>
                  <p className="text-[9px] text-neutral-400 leading-normal mt-0.5 truncate text-left">Soporte técnico integrado para Android y PC.</p>
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {/* MIDROLL COMMERCIAL ANNOUNCEMENT OVERLAY */}
        <AnimatePresence>
          {interactiveAdState !== 'idle' && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-neutral-950/95 backdrop-blur-md z-30 flex flex-col items-center justify-center p-6 text-center"
            >
              {interactiveAdState === 'buffering' ? (
                <div className="flex flex-col items-center gap-4">
                  <Loader2 className="w-12 h-12 text-[#ff0000] animate-spin" />
                  <span className="text-xs uppercase tracking-[0.2em] font-black text-neutral-400">Insertando anuncio integrado...</span>
                </div>
              ) : interactiveAdState === 'running' ? (
                <div className="max-w-md p-8 rounded-2xl bg-neutral-900 border border-white/5 shadow-2xl relative overflow-hidden flex flex-col items-center">
                  <div className="absolute top-0 left-0 w-full h-[3px] bg-amber-500" />
                  <div className="w-12 h-12 rounded-full bg-amber-500/10 text-amber-500 border border-amber-500/20 flex items-center justify-center mb-4">
                    <Sparkles className="w-6 h-6 animate-pulse" />
                  </div>
                  
                  <span className="text-[9px] font-black tracking-widest text-amber-500 uppercase font-mono">Publicidad Comercial</span>
                  <h3 className="text-xl font-bold text-white mt-1.5 mb-2">Canal Integrado con Anuncio publicitario</h3>
                  <p className="text-xs text-neutral-400 leading-relaxed mb-6 text-center">
                    Simulación de rentabilización y ad server en vivo para redes de cable y sistemas directos de televisión.
                  </p>

                  <div className="flex flex-col items-center gap-3 mt-2">
                    <span className="bg-neutral-950 border border-white/10 text-white font-mono rounded-xl px-6 py-3.5 text-sm font-black shadow-2xl flex items-center gap-2">
                      <span className="inline-block w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping" />
                      REANUDANDO EN: <span id="ad-timer-countdown" className="text-amber-400 text-xl font-black tracking-widest">{adTimer}s</span>
                    </span>
                    <p className="text-[10px] text-neutral-500 uppercase tracking-widest font-black font-mono">Pauta comercial obligatoria en reproducción</p>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-green-500/10 text-green-400 flex items-center justify-center border border-green-500/25">
                    ✓
                  </div>
                  <span className="text-sm font-bold text-white">¡Publicidad completada! Reanudando señal...</span>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* ERROR SCREEN */}
        {error && (
          <motion.div 
            key="error-hud"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 flex flex-col items-center justify-center bg-black/95 z-30 p-6 animate-fade-in"
          >
            <div className="max-w-md w-full p-8 rounded-2xl bg-neutral-900 border border-white/5 text-center flex flex-col items-center shadow-2xl">
              <div className="p-3 bg-red-600/10 rounded-full border border-red-500/25 mb-4 text-red-500">
                <AlertCircle className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-bold text-white mb-2 uppercase tracking-wide">Error en Reproducción</h2>
              <p className="text-neutral-400 text-xs leading-relaxed mb-6">{error}</p>
              <div className="flex flex-col sm:flex-row gap-3 w-full">
                <button 
                  onClick={handleReload}
                  className="flex-1 py-3 bg-[#ff0000] hover:bg-red-700 text-white font-bold text-xs uppercase tracking-wider rounded-lg border border-transparent transition-colors shadow-lg active:scale-95 cursor-pointer"
                >
                  Reintentar Conexión
                </button>
                <button 
                  onClick={onBack}
                  className="flex-1 py-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white font-bold text-xs uppercase tracking-wider rounded-lg border border-white/5 transition-colors active:scale-95 cursor-pointer"
                >
                  Volver Atrás
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* LOADING SCREEN */}
        {isLoading && !error && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#09090b] z-20">
            <div className="p-4 bg-white/[0.02] border border-white/5 rounded-3xl flex flex-col items-center">
              <Loader2 className="w-10 h-10 text-[#ff0000] animate-spin mb-3.5" />
              <p className="text-white text-xs font-black uppercase tracking-[0.25em] text-center">Conectando Señal</p>
              <p className="text-[10px] text-neutral-500 font-medium text-center mt-1 animate-pulse">Sincronizando flujos de video HTML5...</p>
            </div>
          </div>
        )}

        {/* CUSTOM PLAYER HUD CONTROLS OVERLAY */}
        {showControls && !error && !isLoading && (
          <React.Fragment>
            {/* TOP BAR ACTION CONTROLLERS */}
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="absolute top-0 left-0 right-0 p-4 sm:p-6 bg-gradient-to-b from-black/95 via-black/40 to-transparent z-20 flex items-center justify-between gap-4"
            >
              <div className="flex items-center gap-3 min-w-0">
                <button 
                  onClick={onBack}
                  className="p-3 bg-black/60 hover:bg-[#ff0000] rounded-full border border-white/10 hover:border-transparent text-white transition-all shadow-xl active:scale-95 cursor-pointer flex items-center justify-center"
                  title="Volver"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>

                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse" />
                    <span className="bg-red-600/10 border border-red-500/20 text-red-500 text-[8px] font-black uppercase px-1 rounded tracking-wider">
                      Live
                    </span>
                    <h2 className="text-sm md:text-base font-bold text-white uppercase tracking-tight truncate max-w-[160px] sm:max-w-[300px] text-left">
                      {currentVideoTitle}
                    </h2>
                  </div>
                  <p className="text-[9px] font-mono text-neutral-450 mt-0.5 truncate hidden sm:block text-left">
                    Señal: {streamUrl}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Refresh Video Source trigger */}
                <button
                  onClick={handleReload}
                  className="p-3 bg-black/60 hover:bg-white/10 rounded-full border border-white/10 text-white transition-all cursor-pointer flex items-center justify-center shadow-xl"
                  title="Actualizar Canal"
                >
                  <RefreshCw className="w-5 h-5" />
                </button>

                <div className="relative">
                  {/* Native Cast Integration API layout helpers */}
                  <style dangerouslySetInnerHTML={{ __html: `
                    google-cast-launcher {
                      position: absolute;
                      top: 0;
                      left: 0;
                      width: 100%;
                      height: 100%;
                      opacity: 0;
                      cursor: pointer;
                      z-index: 10;
                    }
                  `}} />
                  <google-cast-launcher></google-cast-launcher>
                  
                  <button
                    onClick={handleCast}
                    className="p-3 bg-black/60 hover:bg-white/10 rounded-full border border-white/10 text-white transition-all cursor-pointer flex items-center justify-center shadow-lg"
                    title="Transmitir con Chromecast"
                  >
                    <Cast className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>

            {/* ERROR POPUP WINDOW FOR GOOGLE CASTING IN UNSUPPORTED VIEWS */}
            <AnimatePresence>
              {showCastError && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="absolute top-20 right-4 p-5 bg-neutral-900 border border-white/10 rounded-xl max-w-[300px] shadow-2xl z-30 text-xs"
                >
                  <div className="flex gap-2.5 items-start">
                    <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
                    <div>
                      <p className="font-bold text-white mb-0.5">Dispositivo no detectado</p>
                      <p className="text-neutral-400 text-[10px] leading-relaxed">
                        La transmisión nativa requiere abrir la aplicación en una pestaña limpia de Google Chrome o Safari.
                      </p>
                    </div>
                  </div>
                  <a 
                    href={window.location.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-3.5 w-full py-2.5 bg-[#ff0000] rounded-md font-bold text-white uppercase text-[10px] tracking-widest text-center block no-underline hover:bg-red-700 transition"
                  >
                    Abrir en nueva pestaña
                  </a>
                </motion.div>
              )}
            </AnimatePresence>

            {/* FLOATING MIDDLE CENTER CLICK CONTROLS (Only shows if explicitly paused to initiate signal) */}
            {!isPlaying && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
                <button
                  onClick={handlePlayPause}
                  className="p-6 md:p-8 bg-black/55 hover:bg-black/75 rounded-full border border-white/10 text-white shadow-2xl pointer-events-auto transform hover:scale-105 active:scale-95 transition-all flex items-center justify-center cursor-pointer font-black"
                >
                  <Play className="w-8 h-8 md:w-10 md:h-10 text-white fill-white translate-x-0.5" />
                </button>
              </div>
            )}

            {/* FOOTER MEDIA TIME TRACK & CONTROL HUD ACTION CONTAINER */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="absolute bottom-0 left-0 right-0 p-4 sm:p-6 lg:p-8 bg-gradient-to-t from-black via-black/90 to-transparent z-20 flex flex-col gap-3"
            >
              {/* Interactive duration timeline removed as requested to block forward/rewind controls */}

              {/* Lower Deck Controls block */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                
                {/* Play and Live Status indicator controls */}
                <div className="flex items-center justify-between sm:justify-start gap-4">
                  <div className="flex items-center flex-wrap gap-2">
                    {!isPlaying ? (
                      <button
                        onClick={handlePlayPause}
                        className="p-2.5 sm:p-3.5 bg-white text-black hover:bg-neutral-200 rounded-full transition-all active:scale-90 cursor-pointer flex items-center justify-center"
                        title="Iniciar Reproducción"
                      >
                        <Play className="w-4 h-4 sm:w-5 sm:h-5 text-black fill-black" />
                      </button>
                    ) : (
                      <div className="flex items-center gap-2.5 px-3.5 py-2 bg-[#ff0000]/10 border border-[#ff0000]/30 text-[#ff0000] rounded-full text-[10px] font-black uppercase tracking-widest select-none shadow-lg">
                        <span className="w-2 h-2 rounded-full bg-[#ff0000] animate-ping inline-block" />
                        Transmisión Continua
                      </div>
                    )}

                    {/* Loop Toggle */}
                    <button
                      onClick={() => {
                        updateConfig({ loopVideo: !config.loopVideo });
                        showPlayerToast(!config.loopVideo ? "Bucle infinito activado (el video se repetirá siempre)" : "Bucle infinito desactivado");
                      }}
                      className={`px-3 py-1.5 sm:py-2 rounded-full border text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
                        config.loopVideo 
                          ? 'bg-red-600 text-white border-transparent shadow-lg' 
                          : 'bg-black/60 hover:bg-white/10 text-neutral-405 border-white/10'
                      }`}
                      title={config.loopVideo ? "Desactivar bucle infinito" : "Activar bucle infinito"}
                    >
                      <RefreshCw className={`w-3 h-3 ${config.loopVideo ? 'animate-spin' : ''}`} style={{ animationDuration: '8s' }} />
                      Bucle: {config.loopVideo ? 'Sí' : 'No'}
                    </button>

                    {/* Background Music trigger */}
                    <button
                      onClick={() => setIsMusicDrawerOpen(true)}
                      className={`px-3 py-1.5 sm:py-2 rounded-full border text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
                        selectedMusicId 
                          ? 'bg-amber-500 text-neutral-950 border-transparent shadow-lg' 
                          : 'bg-black/60 hover:bg-white/10 text-neutral-405 border-white/10'
                      }`}
                      title="Configurar Sintonía de Música de Fondo"
                    >
                      <Music className={`w-3 h-3 ${isMusicPlaying ? 'animate-pulse' : ''}`} />
                      Música: {selectedMusicId ? 'Activa' : 'Off'}
                    </button>
                  </div>
                </div>

                {/* Sound control slider and specific layouts compatibility buttons */}
                <div className="flex items-center justify-between sm:justify-end gap-5">
                  
                  {/* Trigger dynamic sponsor banner trigger mock */}
                  <button 
                    onClick={triggerSimulatedAd}
                    className="px-2.5 py-1.5 bg-amber-500/10 border border-amber-500/25 text-amber-500 hover:bg-amber-500/20 rounded text-[9px] font-black uppercase tracking-wider transition-all flex items-center gap-1 cursor-pointer"
                    title="Simular corte publicitario integrado"
                  >
                    <Sparkles className="w-3 h-3 animate-spin text-amber-300" />
                    Probar Anuncio
                  </button>

                  {/* Volume controllers block */}
                  <div className="flex items-center gap-2 sm:w-36 select-none">
                    <button
                      onClick={handleToggleMute}
                      className="p-2 hover:bg-white/5 text-neutral-400 hover:text-white transition rounded cursor-pointer"
                      title={isMuted ? "Quitar Silencio" : "Silenciar"}
                    >
                      {isMuted ? <VolumeX className="w-4 h-4 sm:w-5 sm:h-5" /> : <Volume2 className="w-4 h-4 sm:w-5 sm:h-5" />}
                    </button>
                    <input 
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={isMuted ? 0 : volume}
                      onChange={handleVolumeChange}
                      className="w-16 sm:w-24 h-1 bg-white/15 rounded-full appearance-none cursor-pointer focus:outline-none accent-white hover:accent-[#ff0000]"
                    />
                  </div>

                  <div className="h-4 w-[1px] bg-white/10" />

                  <div className="flex items-center gap-1.5">
                    {/* Picture in Picture Floating window button */}
                    {isPipSupported && (
                      <button
                        onClick={handleTogglePip}
                        className="p-2 sm:p-2.5 hover:bg-white/5 text-neutral-400 hover:text-white transition-all rounded cursor-pointer"
                        title="Venta Flotante (PiP)"
                      >
                        <Monitor className="w-4.5 h-4.5 sm:w-5 sm:h-5" />
                      </button>
                    )}

                    {/* Standard Full screen */}
                    <button
                      onClick={toggleFullScreen}
                      className="p-2 sm:p-2.5 hover:bg-white/5 text-neutral-400 hover:text-white transition-all rounded cursor-pointer"
                      title="Pantalla Completa"
                    >
                      {isFullScreen ? (
                        <Minimize className="w-4.5 h-4.5 sm:w-5 sm:h-5" />
                      ) : (
                        <Maximize className="w-4.5 h-4.5 sm:w-5 sm:h-5" />
                      )}
                    </button>
                  </div>

                </div>
              </div>
            </motion.div>
          </React.Fragment>
        )}

        {/* SIDEBAR DRAWER FOR RUNNING BACKGROUND CUSTOM MUSIC */}
        <AnimatePresence>
          {isMusicDrawerOpen && (
            <React.Fragment>
              {/* Back backdrop layer */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.5 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsMusicDrawerOpen(false)}
                className="absolute inset-0 bg-black/60 backdrop-blur-xs z-40 cursor-pointer"
              />

              <motion.div
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                className="absolute top-0 right-0 h-full w-full max-w-md bg-neutral-900 border-l border-white/10 shadow-2xl z-50 flex flex-col overflow-hidden text-left"
              >
                {/* Header title cards */}
                <div className="p-5 border-b border-white/10 flex items-center justify-between bg-neutral-950">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 bg-amber-500/10 text-amber-500 rounded-lg border border-amber-500/25">
                      <Music className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-black uppercase tracking-wider text-white">Música de Fondo</h3>
                      <p className="text-[10px] text-neutral-400 font-medium">Mezcla tus videos con canciones en bucle</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsMusicDrawerOpen(false)}
                    className="p-2 hover:bg-white/15 rounded-lg text-neutral-401 hover:text-white transition-colors cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Main scrollable view contents */}
                <div className="flex-1 overflow-y-auto p-5 space-y-6">
                  
                  {/* Current mixing source dashboard */}
                  <div className="p-4 bg-white/[0.02] border border-white/5 rounded-xl space-y-4">
                    <h4 className="text-xs font-black uppercase text-neutral-400 tracking-wider flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5 text-amber-500" />
                      Mezclador de Canales
                    </h4>

                    {selectedMusicId ? (
                      <div className="space-y-3">
                        <div className="bg-neutral-950 rounded-lg p-3 border border-white/5 flex items-center gap-2.5">
                          <Disc className="w-8 h-8 text-amber-400 animate-spin" style={{ animationDuration: '4s' }} />
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-bold text-white truncate max-w-[200px]">
                              {localSongs.find(s => s.id === selectedMusicId)?.title || "Música sin nombre"}
                            </p>
                            <span className="text-[9px] font-mono text-amber-400 font-bold uppercase tracking-wider block mt-0.5">
                              En reproducción continua
                            </span>
                          </div>
                          <button
                            onClick={() => setSelectedMusicId('')}
                            className="bg-neutral-800 hover:bg-red-950 text-neutral-400 hover:text-red-400 p-2 rounded-md border border-white/5 hover:border-red-500/20 text-[10px] uppercase font-black tracking-wider transition-colors cursor-pointer"
                          >
                            Detener
                          </button>
                        </div>

                        {/* Mixed Independent Volume Control */}
                        <div className="space-y-1.5 selection:bg-none">
                          <div className="flex items-center justify-between text-[11px] font-bold text-neutral-405">
                            <span>Volumen de la Música</span>
                            <span className="text-amber-400 font-mono">{Math.round((config.backgroundMusicVolume !== undefined ? config.backgroundMusicVolume : 0.5) * 100)}%</span>
                          </div>
                          <input 
                            type="range"
                            min="0"
                            max="1"
                            step="0.05"
                            value={config.backgroundMusicVolume !== undefined ? config.backgroundMusicVolume : 0.5}
                            onChange={(e) => {
                              updateConfig({ backgroundMusicVolume: parseFloat(e.target.value) });
                            }}
                            className="w-full h-1 bg-white/10 rounded-full appearance-none cursor-pointer focus:outline-none accent-amber-500"
                          />
                        </div>
                      </div>
                    ) : (
                      <p className="text-xs text-neutral-450 leading-relaxed italic text-center py-2.5">
                        No hay ninguna pista seleccionada. Elige o sube un archivo de música abajo para reproducirlo con el video.
                      </p>
                    )}
                  </div>

                  {/* Manual file custom uploader card */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-black uppercase text-neutral-400 tracking-wider">
                      Subir Nueva Música
                    </h4>
                    
                    <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-white/10 hover:border-amber-500/40 rounded-xl bg-white/[0.01] hover:bg-amber-500/[0.02] transition-all cursor-pointer group text-center relative">
                      <input 
                        type="file"
                        accept="audio/*"
                        className="hidden"
                        onChange={handleMusicUpload}
                        disabled={isUploadingMusic}
                      />
                      
                      {isUploadingMusic ? (
                        <div className="flex flex-col items-center py-2">
                          <Loader2 className="w-8 h-8 text-amber-500 animate-spin mb-3" />
                          <span className="text-xs font-black uppercase tracking-wider text-white">Sincronizando pista ({musicProgress}%)</span>
                          <span className="text-[10px] text-neutral-500 mt-1">Almacenando permanentemente en el navegador...</span>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center py-2">
                          <Upload className="w-8 h-8 text-neutral-400 group-hover:text-amber-400 transition-colors mb-3" />
                          <span className="text-xs font-black uppercase text-neutral-200 tracking-wider">Explorar archivo de audio</span>
                          <span className="text-[10px] text-neutral-500 mt-1 max-w-[200px] leading-normal mx-auto">
                            Soporta formatos comunes de audio MP3, WAV, M4A localmente.
                          </span>
                        </div>
                      )}
                    </label>
                  </div>

                  {/* Customized Library checklist scroll area */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-black uppercase text-neutral-400 tracking-wider">
                        Tu Librería Musical
                      </h4>
                      <span className="text-[9px] font-mono text-neutral-500 uppercase tracking-widest">
                        {localSongs.length} Pistas
                      </span>
                    </div>

                    <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                      {localSongs.length === 0 ? (
                        <div className="text-center py-8 rounded-xl border border-white/5 bg-white/[0.005]">
                          <Music className="w-6 h-6 text-neutral-600 mx-auto mb-2" />
                          <p className="text-xs text-neutral-500 font-bold">Librería musical vacía</p>
                          <p className="text-[10px] text-neutral-600 mt-1 max-w-[170px] mx-auto">
                            ¡Sube tus canciones de fondo favoritas arriba!
                          </p>
                        </div>
                      ) : (
                        localSongs.map((song) => {
                          const isActive = selectedMusicId === song.id;
                          return (
                            <div 
                              key={song.id} 
                              className={`p-3 rounded-lg border flex items-center justify-between gap-3 transition-all ${
                                isActive 
                                  ? 'bg-amber-500/10 border-amber-500/30' 
                                  : 'bg-white/[0.01] hover:bg-white/[0.03] border-white/5 border-neutral-800'
                              }`}
                            >
                              <div 
                                onClick={() => setSelectedMusicId(song.id)}
                                className="min-w-0 flex-1 cursor-pointer"
                              >
                                <p className="text-xs font-bold text-white truncate pr-2">
                                  {song.title}
                                </p>
                                <div className="flex items-center gap-2 mt-1">
                                  <span className="text-[9px] font-mono text-zinc-500 font-bold">
                                    {song.sizeCount}
                                  </span>
                                  {isActive && (
                                    <span className="text-[9px] font-mono font-black text-amber-400 uppercase tracking-widest animate-pulse flex items-center gap-1">
                                      ● Activo
                                    </span>
                                  )}
                                </div>
                              </div>

                              <button
                                onClick={() => handleMusicDelete(song.id, song.title)}
                                className="p-1.5 hover:bg-red-500/20 text-neutral-500 hover:text-red-400 border border-transparent hover:border-red-500/10 rounded-md transition-colors cursor-pointer"
                                title="Eliminar Pista"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>

                </div>

                {/* Footer notes guidelines for absolute premium aesthetics */}
                <div className="p-4 bg-neutral-950 border-t border-white/10 text-[10px] text-neutral-500 leading-relaxed text-center">
                  La música se transmitirá de fondo y se mezclará en tiempo real con el reproductor de televisión de forma independiente sin silenciar tus videos.
                </div>
              </motion.div>
            </React.Fragment>
          )}
        </AnimatePresence>

        {/* FLOATING ACTION HUD NOTIFICATION TOAST BAR */}
        <AnimatePresence>
          {playerToast && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 15 }}
              className="absolute top-24 left-1/2 -translate-x-1/2 px-4 py-2.5 bg-black/95 backdrop-blur-md rounded-full border border-white/15 text-[11px] font-bold text-white shadow-2xl z-50 flex items-center gap-2 max-w-[280px]"
            >
              <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
              <span className="truncate">{playerToast}</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
