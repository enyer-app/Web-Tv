import React, { useEffect, useState } from 'react';
import { Play, Tv, Wifi, Settings } from 'lucide-react';
import { motion } from 'motion/react';
import { useRemoteControl } from '../hooks/useRemoteControl';
import { useAppConfig } from '../context/ConfigContext';

interface HomeScreenProps {
  onStart: () => void;
}

export function HomeScreen({ onStart }: HomeScreenProps) {
  const { config } = useAppConfig();
  const [time, setTime] = useState(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  useRemoteControl((action) => {
    if (action === 'enter') {
      onStart();
    }
  });

  return (
    <div className="fixed inset-0 bg-[#050505] flex flex-col items-center justify-center p-8 md:p-12 lg:p-16">
      {/* Top Header Bar */}
      <div className="w-full flex justify-between items-center px-6 md:px-12 absolute top-8 md:top-12 lg:top-16 left-0 right-0 z-20">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5 opacity-75">
            <Wifi className="w-4 h-4 md:w-5 md:h-5 text-green-500" />
            <span className="text-xs md:text-sm uppercase tracking-[0.2em] font-medium hidden sm:inline">Señal Estable</span>
          </div>
        </div>
        
        <div className="flex items-center gap-4 md:gap-6">
          <div className="text-xl md:text-3xl font-light tracking-widest">{time}</div>
          <button
            onClick={() => {
              window.location.hash = 'admin';
            }}
            className="flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 bg-white/[0.04] hover:bg-[#ff0000]/10 border border-white/10 hover:border-[#ff0000]/30 rounded-lg text-xs font-bold uppercase tracking-wider text-neutral-300 hover:text-white transition-all cursor-pointer active:scale-95 z-30"
            title="Panel de Administración"
          >
            <Settings className="w-4 h-4 text-[#ff0000] animate-spin-slow" />
            <span className="hidden sm:inline">Panel</span>
          </button>
        </div>
      </div>

      <div className="flex flex-col items-center justify-center relative w-full">
        {/* Background Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] md:w-[600px] h-[300px] md:h-[600px] bg-white/[0.03] rounded-full blur-[60px] md:blur-[100px] pointer-events-none" />
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="relative z-10 flex flex-col items-center animate-fadeIn w-full max-w-4xl px-4"
        >
          <div className="w-32 h-32 md:w-48 md:h-48 bg-white/5 rounded-full flex items-center justify-center border border-white/10 mb-6 md:mb-8 shadow-inner overflow-hidden">
            <Tv className="w-12 h-12 md:w-20 md:h-20 text-white opacity-80" strokeWidth={1.2} />
          </div>

          <div className="bg-[#ff0000] text-white px-2 py-1 md:px-3 md:py-1 rounded-sm font-bold text-[10px] md:text-sm uppercase tracking-widest animate-pulse-live mb-4 md:mb-6">
            En Vivo
          </div>

          <h1 className="text-3xl md:text-[48px] font-black text-white mb-8 md:mb-14 tracking-[-1px] uppercase leading-tight text-center">
            Reproductor de Video
          </h1>

          <motion.button
            whileFocus={{ scale: 1.05 }}
            whileHover={{ scale: 1.02 }}
            onClick={onStart}
            autoFocus
            className="px-10 py-4 md:px-16 md:py-6 bg-white text-black rounded-lg text-lg md:text-2xl font-bold uppercase tracking-tight transition-all focus:ring-4 focus:ring-white focus:ring-offset-0 outline-none cursor-pointer"
          >
            VER EN VIVO
          </motion.button>
        </motion.div>
      </div>

      <div className="absolute bottom-0 left-0 w-full h-1 bg-white/10 overflow-hidden">
        <motion.div 
          initial={{ x: '-100%' }}
          animate={{ x: '0%' }}
          transition={{ duration: 1.5, ease: "circOut" }}
          className="h-full bg-white/30 w-1/3 shadow-[0_0_10px_white]" 
        />
      </div>
    </div>
  );
}

