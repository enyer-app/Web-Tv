import React, { useEffect, useRef } from 'react';

interface AdScriptLoaderProps {
  htmlCode: string;
}

export function AdScriptLoader({ htmlCode }: AdScriptLoaderProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!htmlCode || !containerRef.current) return;

    // Clear previous elements
    containerRef.current.innerHTML = "";

    // Standard script tags don't run automatically via innerHTML assignment.
    // We must manually parse, clone, and insert each element so script engines process them correctly.
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = htmlCode;

    // Extract all children and separate standard markup from script tags
    Array.from(tempDiv.childNodes).forEach((node) => {
      if (node.nodeName === "SCRIPT") {
        const scriptElement = node as HTMLScriptElement;
        const newScript = document.createElement("script");
        
        // Copy all attributes
        Array.from(scriptElement.attributes).forEach((attr) => {
          newScript.setAttribute(attr.name, attr.value);
        });

        // Copy content or src
        if (scriptElement.src) {
          newScript.src = scriptElement.src;
          newScript.async = true;
        } else {
          newScript.textContent = scriptElement.textContent;
        }
        
        containerRef.current?.appendChild(newScript);
      } else {
        // Standard elements like style sheets, dynamic divs, or static banners
        containerRef.current?.appendChild(node.cloneNode(true));
      }
    });
  }, [htmlCode]);

  if (!htmlCode) return null;

  // Render centered in a beautiful banner slot at the bottom of the screens below player or homepage
  return (
    <div 
      ref={containerRef} 
      className="ad-script-container w-full max-w-4xl mx-auto flex items-center justify-center py-4 px-6 z-40 overflow-hidden bg-black/40 border border-white/5 rounded-xl text-neutral-400 text-xs shadow-xl"
    />
  );
}
