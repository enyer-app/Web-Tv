import React, { createContext, useContext, useState, useEffect } from 'react';
import { APP_CONFIG } from '../config';
import { db, auth, OperationType, handleFirestoreError } from '../lib/firebase';
import { doc, onSnapshot, setDoc, getDoc, getDocFromServer } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';

export interface VideoItem {
  id: string;
  title: string;
  url: string;
}

export interface AppConfigData {
  appName: string;
  channelTitle: string;
  streamUrl: string;
  adVideoUrl: string;
  adDurationSeconds: number;
  enableAd: boolean;
  isMaintenanceMode: boolean;
  adScriptCode: string;
  videoLibrary: VideoItem[];
  loopVideo?: boolean;
  musicLibrary?: VideoItem[];
  backgroundMusicUrl?: string;
  backgroundMusicVolume?: number;
}

const DEFAULT_VIDEOS: VideoItem[] = [
  {
    id: "preset-mux-hls",
    title: "Señal de Prueba Mux HLS",
    url: "https://test-streams.mux.dev/x36xhz/x36xhz.m3u8"
  },
  {
    id: "preset-sintel-hls",
    title: "Sintel Demo HLS",
    url: "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8"
  },
  {
    id: "preset-bunny-mp4",
    title: "Big Buck Bunny MP4",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
  }
];

const STORAGE_KEY = 'tv_live_pro_config';

interface ConfigContextType {
  config: AppConfigData;
  updateConfig: (updater: Partial<AppConfigData> | ((prev: AppConfigData) => AppConfigData)) => void;
  resetToDefaults: () => void;
  setActiveStream: (url: string, title?: string) => void;
  loading: boolean;
}

const ConfigContext = createContext<ConfigContextType | undefined>(undefined);

const DEFAULT_CONFIG: AppConfigData = {
  appName: APP_CONFIG.appName,
  channelTitle: 'CANAL PREMIUM HD',
  streamUrl: APP_CONFIG.streamUrl,
  adVideoUrl: APP_CONFIG.adVideoUrl,
  adDurationSeconds: APP_CONFIG.adDurationSeconds,
  enableAd: true,
  isMaintenanceMode: APP_CONFIG.isMaintenanceMode,
  adScriptCode: "",
  videoLibrary: DEFAULT_VIDEOS,
  loopVideo: true,
  musicLibrary: [],
  backgroundMusicUrl: "",
  backgroundMusicVolume: 0.5
};

export function ConfigProvider({ children }: { children: React.ReactNode }) {
  const [config, setConfig] = useState<AppConfigData>(DEFAULT_CONFIG);
  const [loading, setLoading] = useState<boolean>(true);

  // CRITICAL CONSTRAINT: Test Firestore connection when the application initially boots using getFromServer
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test-connection-doc', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    }
    testConnection();
  }, []);

  // Sync state in real-time using onSnapshot
  useEffect(() => {
    const configDocRef = doc(db, 'configs', 'global');
    
    const unsubscribe = onSnapshot(configDocRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setConfig({
          appName: data.appName || DEFAULT_CONFIG.appName,
          channelTitle: data.channelTitle || DEFAULT_CONFIG.channelTitle,
          streamUrl: data.streamUrl || DEFAULT_CONFIG.streamUrl,
          adVideoUrl: data.adVideoUrl || DEFAULT_CONFIG.adVideoUrl,
          adDurationSeconds: typeof data.adDurationSeconds === 'number' ? data.adDurationSeconds : DEFAULT_CONFIG.adDurationSeconds,
          enableAd: data.enableAd !== undefined ? data.enableAd : DEFAULT_CONFIG.enableAd,
          isMaintenanceMode: data.isMaintenanceMode !== undefined ? data.isMaintenanceMode : DEFAULT_CONFIG.isMaintenanceMode,
          adScriptCode: data.adScriptCode || DEFAULT_CONFIG.adScriptCode,
          videoLibrary: data.videoLibrary || DEFAULT_CONFIG.videoLibrary,
          loopVideo: data.loopVideo !== undefined ? data.loopVideo : true,
          musicLibrary: data.musicLibrary || [],
          backgroundMusicUrl: data.backgroundMusicUrl || "",
          backgroundMusicVolume: typeof data.backgroundMusicVolume === 'number' ? data.backgroundMusicVolume : 0.5,
        });
      } else {
        // Initial local fallback configuration if Firestore is empty
        setConfig(DEFAULT_CONFIG);
      }
      setLoading(false);
    }, (error) => {
      console.warn("Firestore config read denied, using fallback values. Expected for locked rules", error);
      
      // Fallback local storage configurations
      try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
          setConfig(JSON.parse(stored));
        }
      } catch (e) {
        console.error("LocalStorage fallback read failed", e);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Auto-seeds defaults on database instance when verified admin is detected online
  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, async (user) => {
      if (user && (user.email === 'enyer0324@gmail.com' || user.email === 'enyer0389@gmail.com')) {
        try {
          const configDocRef = doc(db, 'configs', 'global');
          const docSnap = await getDoc(configDocRef);
          if (!docSnap.exists()) {
            await setDoc(configDocRef, DEFAULT_CONFIG);
            console.log("Firestore database seeded with defaults successfully.");
          }
        } catch (error) {
          console.warn("Could not seed default config to Firestore directly:", error);
        }
      }
    });

    return () => unsubAuth();
  }, []);

  const updateConfig = async (updater: Partial<AppConfigData> | ((prev: AppConfigData) => AppConfigData)) => {
    let nextConfig: AppConfigData | null = null;
    setConfig((prev) => {
      const next = typeof updater === 'function' ? updater(prev) : { ...prev, ...updater };
      nextConfig = next;
      
      // Keep LocalStorage updated as offline resilience
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch (e) {
        console.error("Local storage save failed:", e);
      }

      return next;
    });

    // Write directly to cloud database if Admin is authenticated in Firestore
    const user = auth.currentUser;
    if (user && (user.email === 'enyer0324@gmail.com' || user.email === 'enyer0389@gmail.com')) {
      try {
        const configDocRef = doc(db, 'configs', 'global');
        // Wait minor tick for nextConfig reference security
        setTimeout(async () => {
          if (nextConfig) {
            try {
              await setDoc(configDocRef, nextConfig, { merge: true });
            } catch (error) {
              handleFirestoreError(error, OperationType.WRITE, 'configs/global');
            }
          }
        }, 50);
      } catch (error) {
        console.error("Failed to sync updated config to cloud Firestore database:", error);
      }
    }
  };

  const resetToDefaults = async () => {
    setConfig(DEFAULT_CONFIG);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_CONFIG));
    } catch (e) {
      console.error(e);
    }

    const user = auth.currentUser;
    if (user && (user.email === 'enyer0324@gmail.com' || user.email === 'enyer0389@gmail.com')) {
      try {
        const configDocRef = doc(db, 'configs', 'global');
        await setDoc(configDocRef, DEFAULT_CONFIG);
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, 'configs/global');
      }
    }
  };

  const setActiveStream = (url: string, title?: string) => {
    updateConfig({
      streamUrl: url,
      ...(title ? { channelTitle: title.toUpperCase() } : {})
    });
  };

  return (
    <ConfigContext.Provider value={{ config, updateConfig, resetToDefaults, setActiveStream, loading }}>
      {children}
    </ConfigContext.Provider>
  );
}

export function useAppConfig() {
  const context = useContext(ConfigContext);
  if (!context) {
    throw new Error('useAppConfig must be used within a ConfigProvider');
  }
  return context;
}
