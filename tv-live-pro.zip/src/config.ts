export const APP_CONFIG = {
  appName: "TV Live Pro",
  streamUrl: "https://test-streams.mux.dev/x36xhz/x36xhz.m3u8", // Stream HLS de prueba por defecto de alta calidad
  isMaintenanceMode: false,
  adDurationSeconds: 5,
  adVideoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4", // Anuncio de prueba por defecto
  adScriptCode: "" // Código HTML/JS de Red de Anuncios real (AdSense, PropellerAds, Popunder, Banner, etc.)
};
