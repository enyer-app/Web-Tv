export interface LocalVideoFile {
  id: string;
  title: string;
  blob: Blob;
  sizeCount: string;
  createdAt: number;
}

const DB_NAME = 'tv_live_pro_db';
const DB_VERSION = 1;
const STORE_NAME = 'videos';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);

    request.onupgradeneeded = (event) => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
  });
}

export async function saveVideoFile(title: string, blob: Blob): Promise<LocalVideoFile> {
  const db = await openDB();
  const sizeMB = (blob.size / (1024 * 1024)).toFixed(1);
  
  const newItem: LocalVideoFile = {
    id: `local-${Date.now()}`,
    title: title,
    blob: blob,
    sizeCount: `${sizeMB} MB`,
    createdAt: Date.now()
  };

  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.put(newItem);

    request.onsuccess = () => resolve(newItem);
    request.onerror = () => reject(request.error);
  });
}

export async function getAllVideoFiles(): Promise<Omit<LocalVideoFile, 'blob'>[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.getAll();

    request.onsuccess = () => {
      // Exclude the heavy blobs when just listing elements to prevent blocking memory
      const items = request.result as LocalVideoFile[];
      const listings = items
        .filter(item => !item.id.startsWith('local-music-'))
        .map(({ id, title, sizeCount, createdAt }) => ({
          id,
          title,
          sizeCount,
          createdAt
        }));
      resolve(listings);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function getAllAudioFiles(): Promise<Omit<LocalVideoFile, 'blob'>[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.getAll();

    request.onsuccess = () => {
      const items = request.result as LocalVideoFile[];
      const listings = items
        .filter(item => item.id.startsWith('local-music-'))
        .map(({ id, title, sizeCount, createdAt }) => ({
          id,
          title,
          sizeCount,
          createdAt
        }));
      resolve(listings);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function saveAudioFile(title: string, blob: Blob): Promise<LocalVideoFile> {
  const db = await openDB();
  const sizeMB = (blob.size / (1024 * 1024)).toFixed(1);
  
  const newItem: LocalVideoFile = {
    id: `local-music-${Date.now()}`,
    title: title,
    blob: blob,
    sizeCount: `${sizeMB} MB`,
    createdAt: Date.now()
  };

  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.put(newItem);

    request.onsuccess = () => resolve(newItem);
    request.onerror = () => reject(request.error);
  });
}

export async function getVideoBlob(id: string): Promise<Blob | null> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.get(id);

    request.onsuccess = () => {
      const item = request.result as LocalVideoFile | undefined;
      resolve(item ? item.blob : null);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function deleteVideoFile(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.delete(id);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/**
 * Automagically parses and converts standard cloud storage links 
 * (Google Drive, Dropbox, OneDrive) into raw direct video streaming URLs.
 */
export function autoConvertCloudUrl(url: string): { convertedUrl: string; wasConverted: boolean; serviceName: string } {
  const cleanUrl = url.trim();
  const lowerUrl = cleanUrl.toLowerCase();
  
  // 1. Dropbox detector
  // Example: https://www.dropbox.com/scl/fi/xxxx/video.mp4?rlkey=xxxx&dl=0
  // Convert to dl.dropboxusercontent.com for direct raw stream (avoids redirect bugs in some video engines)
  if (lowerUrl.includes('dropbox.com')) {
    let newUrl = cleanUrl.replace(/www\.dropbox\.com/i, 'dl.dropboxusercontent.com');
    if (newUrl.includes('dl=0')) {
      newUrl = newUrl.replace('dl=0', 'raw=1');
    } else if (newUrl.includes('dl=1')) {
      newUrl = newUrl.replace('dl=1', 'raw=1');
    } else if (!newUrl.includes('raw=1')) {
      const separator = newUrl.includes('?') ? '&' : '?';
      newUrl = `${newUrl}${separator}raw=1`;
    }
    return {
      convertedUrl: newUrl,
      wasConverted: newUrl !== cleanUrl,
      serviceName: 'Dropbox (Directo)'
    };
  }

  // 2. Google Drive detector
  // Match file id from different Google Drive link patterns
  let googleFileId = '';
  
  // Pattern A: /file/d/([a-zA-Z0-9_-]+)
  const fileDMatch = cleanUrl.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (fileDMatch && fileDMatch[1]) {
    googleFileId = fileDMatch[1];
  } else {
    // Pattern B: id=([a-zA-Z0-9_-]+)
    const idMatch = cleanUrl.match(/[?&]id=([a-zA-Z0-9_-]+)/);
    if (idMatch && idMatch[1] && (lowerUrl.includes('drive.google.com') || lowerUrl.includes('docs.google.com'))) {
      googleFileId = idMatch[1];
    }
  }

  if (googleFileId) {
    // Direct stream bypass via user content download endpoint to bypass virus check on big files (>100MB)
    const converted = `https://drive.usercontent.google.com/download?id=${googleFileId}&export=download&confirm=t`;
    return {
      convertedUrl: converted,
      wasConverted: true,
      serviceName: 'Google Drive (Bypass de restricción)'
    };
  }

  // 3. OneDrive / Live.com detector
  // Match onedrive URLs (onedrive.live.com or personal.onedrive.com)
  if (lowerUrl.includes('onedrive.live.com') || lowerUrl.includes('onedrive.com') || lowerUrl.includes('1drv.ms')) {
    let newUrl = cleanUrl;
    if (newUrl.includes('/embed?')) {
      newUrl = newUrl.replace('/embed?', '/download?');
    } else if (newUrl.includes('/redir?')) {
      newUrl = newUrl.replace('/redir?', '/download?');
    }
    return {
      convertedUrl: newUrl,
      wasConverted: newUrl !== cleanUrl,
      serviceName: 'OneDrive (Directo)'
    };
  }

  // Default to original URL
  return {
    convertedUrl: cleanUrl,
    wasConverted: false,
    serviceName: 'Stream directo'
  };
}
